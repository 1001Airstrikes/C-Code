#include<iostream>
#include "Viewer.h"

using namespace std;

int main()
{
    Viewer x;
    x.run();

    return 0;
}
