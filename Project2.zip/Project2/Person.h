#include<iostream>

class Person
{
public:
    std::string fname_;
    std::string category_;
    int year_;
    std::string status_;

private:

};
