#include<iostream>
#include<algorithm>

template<class T>
class Node
{
public:
    Node() : element(), next(nullptr) {}
    Node(const T & e, Node * next0) : element(e), next(next0) {}
    ~Node() {next = nullptr;}

    T element;
    Node<T> * next;
};

template<class T>
class Queue
{
public:
    Queue();
    Queue(const Queue<T> & qu);
    ~Queue();

    void push(const T & e);
    T pop();
    int size() {return size_;}
    bool empty() {return size_ == 0;}
    T & front() {return head_node_->element;}
    void clear() {head_node_ = tail_node_ = nullptr; size_ = 0;}
    Queue<T> & operator=(const Queue<T> & rhs);
    void print();

private:
    Node<T> * head_node_;
    Node<T> * tail_node_;
    int size_;
};

template<class T>
inline Queue<T>::Queue() : size_(0)
{
    head_node_ = new Node<T>;
    head_node_->next = head_node_;
    tail_node_ = head_node_;
    ++size_;
}

template<class T>
inline Queue<T>::Queue(const Queue<T> & qu) : Queue<T>()
{
    auto node = new Node<T>();
    node = qu.head_node_;
    head_node_->element = node->element;
    for (int i = 1; i < qu.size_; ++i)
    {
        node = node->next;
        push(node->element);
    }
}

template<class T>
inline Queue<T>::~Queue()
{
    while(size_ != 0)
        pop();
    delete head_node_;
}

template<class T>
inline void Queue<T>::push(const T & e)
{
    auto new_node = new Node<T>(e, head_node_);
    tail_node_->next = new_node;
    tail_node_ = new_node;
    ++size_;
}

template<class T>
T Queue<T>::pop()
{
    T e = head_node_->element;
    auto x = head_node_;
    head_node_ = head_node_->next;
    delete x;
    tail_node_->next = head_node_;
    --size_;
    return e;
}

template<class T>
Queue<T> & Queue<T>::operator=(const Queue<T> & rhs)
{
    Queue<T> temp = rhs;
    std::swap(head_node_, temp.head_node_);
    std::swap(tail_node_, temp.tail_node_);
    std::swap(size_, temp.size_);
    return *this;
}

template<class T>
inline void Queue<T>::print()
{
    auto node = new Node<T>();
    node = head_node_;
    for (int i = 0; i < size_; ++i)
    {
        std::cout << node->element << ' ';
        node = node->next;
    }
    std::cout << std::endl;
}

int main()
{
    Queue<int> qu;
    qu.push(12);
    qu.push(24);
    qu.push(36);
    qu.pop();
    qu.print();
    std::cout << qu.front() << ' ' << qu.size() << std::endl;

    auto a = qu;
    a.print();
    a.clear();
    std::cout << a.empty() << std::endl;

    return 0;
}

