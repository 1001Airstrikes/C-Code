#include<iostream>
#include<algorithm>

template<class T>
class Node
{
public:
    Node() : element(), next(nullptr) {}
    Node(const T & e, Node * next0) : element(e), next(next0) {}
    ~Node() {next = nullptr;}

    T element;
    Node<T> * next;
};

template<class T>
class Queue
{
public:
    Queue();
    Queue(const Queue<T> & qu);
    ~Queue();

    void push(const T & e);
    T pop();
    int size() {return size_;}
    bool empty() {return size_ == 0;}
    T & front() {return head_node_->element;}
    void clear() {head_node_ = tail_node_ = nullptr; size_ = 0;}
    Queue<T> & operator=(const Queue<T> & rhs);
    void print();

private:
    Node<T> * head_node_;
    Node<T> * tail_node_;
    int size_;
};
