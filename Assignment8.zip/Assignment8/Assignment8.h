#include<iostream>

class String
{
public:
    String() : buffer_(nullptr), size_(0) {}
    String(const char* c_str);
    String(const String & s);
    ~String() {delete [] buffer_;}

    int length() const {return size_;}
    char & operator[](int i) {return buffer_[i];}
    const char & operator[](int i) const {return buffer_[i];}
    void clear();
    String operator+(String s);
    String & operator=(String s);
    const char * c_str();
    void print();

private:
    char * get_new_buffer(int n) const;

    char * buffer_;
    int size_;
};

inline char * String::get_new_buffer(int n) const
{
    return (n == 0 ? nullptr : new char[n]{});
}

inline void String::clear()
{
    delete [] buffer_;
    buffer_ = nullptr;
    size_ = 0;
}

inline void String::print()
{
    for(int i = 0; i < size_; i++)
        std::cout << buffer_[i];
    std::cout << std::endl;
}

