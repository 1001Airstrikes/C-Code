#include<iostream>
#include<string>
#include "Assignment8.h"

template<class T>
T * subarray(const T * a, int i, int m)
{
    T * sub = new T[m-i]{};
    for(int x = i; x < m; x++)
        sub[x-i] = a[x];
    return sub;
}

int main()
{
    int* array1 = new int[5]{1,2,3,4,5};
    int* array2 = subarray(array1, 2, 5);
    std::cout << array2[0] << array2 [2] << "\n\n";

    std::string x = "Hello";
    const char* cs = x.c_str();
    String s(cs);
    s.print();
    String s2(s);
    s2.print();
    s.clear();
    s.print();
    String s3 = s2 + s2;
    s3.print();
    cs = s3.c_str();
    std::cout << cs[0] << std::endl;

    return 0;
}
